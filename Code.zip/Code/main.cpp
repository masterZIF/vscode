#include<iostream>
using namespace std;
int main()
{
    // 输出Hello world!
    cout<<"Hello world!\n";

    // 循环，输出0～9
    int i=0;
    while(i<10){
        cout<<i<<" ";
        i+=1;
    }
    printf("\n");
    return 0;
}
