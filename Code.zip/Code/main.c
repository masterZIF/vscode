#include<stdio.h>
int main()
{
    // 输出Hello world!
    printf("Hello world!\n");

    // 循环，输出0～9
    int i=0;
    while(i<10){
        printf("%d ", i);
        i+=1;
    }
    printf("\n");
    return 0;
}
